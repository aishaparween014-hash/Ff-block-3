package com.example.ffblocker;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;

public class KeepAliveService extends Service {
    static final String CH = "ffblock";
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable r = new Runnable() {
        public void run() {
            try {
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(1, build());
            } catch (Exception e) {}
            h.postDelayed(this, 5000);
        }
    };

    static boolean enabled(Context c) {
        return c.getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("enabled", false);
    }

    static boolean accOn(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName() + "/");
    }

    public static void start(Context c) {
        try {
            Intent i = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception e) {}
    }

    static void scheduleRestart(Context c) {
        try {
            if (!enabled(c)) return;
            Intent i = new Intent(c, KeepAliveService.class);
            PendingIntent pi;
            if (Build.VERSION.SDK_INT >= 26)
                pi = PendingIntent.getForegroundService(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            else
                pi = PendingIntent.getService(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT);
            AlarmManager am = (AlarmManager) c.getSystemService(ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1500, pi);
        } catch (Exception e) {}
    }

    Notification build() {
        boolean ok = accOn(this);
        String txt = ok ? "Free Fire ब्लॉकर चालू है 🔒" : "⚠️ Accessibility बंद है। ऐप खोलकर ON करो";
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, CH);
        else b = new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_lock)
         .setContentTitle("FF Blocker")
         .setContentText(txt)
         .setOngoing(true);
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setContentIntent(open);
        return b.build();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "FF Blocker", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        startForeground(1, build());
        h.postDelayed(r, 5000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!enabled(this)) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        scheduleRestart(this);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(r);
        scheduleRestart(this);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package com.example.ffblocker;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

public class BlockService extends AccessibilityService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private long lastToast = 0;
    private final Runnable r = new Runnable() {
        public void run() {
            check(null);
            h.postDelayed(this, 1500);
        }
    };

    @Override
    protected void onServiceConnected() {
        if (KeepAliveService.enabled(this)) KeepAliveService.start(this);
        h.removeCallbacks(r);
        h.post(r);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence p = event == null ? null : event.getPackageName();
        check(p == null ? null : p.toString());
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        h.removeCallbacks(r);
        super.onDestroy();
    }

    private void check(String pkgFromEvent) {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        if (System.currentTimeMillis() < p.getLong("endTime", 0)) return;

        String s = pkgFromEvent;
        if (s == null) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;
            CharSequence pkg = root.getPackageName();
            if (pkg == null) return;
            s = pkg.toString();
        }

        if (s.equals("com.dts.freefireth") || s.equals("com.dts.freefiremax")) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            long now = System.currentTimeMillis();
            if (now - lastToast > 3000) {
                lastToast = now;
                Toast.makeText(this, "Free Fire ब्लॉक है 🔒", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
